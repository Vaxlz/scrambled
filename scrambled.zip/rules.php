<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once('_inc/head.php'); ?>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php require_once('_inc/navbar.php'); ?>
    <div class="indexentirescreen">
        <div>
            <center>
            <h>Rules</h>
            <br>
            <p>Unscramble as many words as you can in 60 seconds! Click on the letters in order of how the word should be spelt.</p>
            </center>
        </div>
    </div>
</body>
</html>