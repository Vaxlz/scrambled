<nav>
    <div class="topnav">
        <div class="logo">
            <h>Scrambled</h>
        </div>
        <div class="navlinks">
            <a href="index.php">Home</a>
            <a href="play.php">Play</a>
        </div>
        <div class="navbuttons" style="cursor: pointer;">
            <a href="wordslist.php" style="padding-right: 15px;">Word List</a>
            <a href="rules.php">Rules</a>
        </div>
    </div>
</nav>