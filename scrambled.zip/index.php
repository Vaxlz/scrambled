<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once('_inc/head.php'); ?>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php require_once('_inc/navbar.php'); ?>
    <div class="indexentirescreen">
        <div style="box-sizing: border-box;position:absolute;">
            <center>
            <h>Home</h>
            <br>
            <p>UNSCRAMBLE the words to CRACK the code!</p>
            <video style="border-color: black;border-style: solid;border-width: 5px;" width="1280" height="720" autoplay="autoplay" playsinline>
                <source src="assets/images/Tutorial vid (1).mp4" type="video/mp4">
            </video>
            </center>
        </div>
    </div>
</body>
</html>